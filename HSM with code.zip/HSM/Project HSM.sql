Create  database HMS_db;
-----------------------------------------------------------------------------
create proc createTables
AS
create table LoginAsDoctor
(UserName varchar(30) Not Null,
Password varchar(30) Not Null);
insert LoginAsDoctor values ('doctor','doctor');

create table LoginAsAdmin 
(UserName varchar(30) Not Null
,Password varchar(30)Not Null);
insert LoginAsAdmin values ('admin','admin');

create table LoginAsRep
(UserName varchar(30)Not Null,
Password varchar(30)Not Null);
insert LoginAsRep values ('rep','rep');

create table DoctorRecord(
ID  integer Identity(1,1)Not Null primary key, 
FirstName varchar(30)Not Null,
LastName varchar(30)Not Null,
DoctorID varchar(30)Not Null,
Address varchar(100)Not Null,
City varchar(30)Not Null,
CNIC varchar(30)Not Null,
PhoneNo varchar(30)Not Null,
Email varchar(30)Not Null,
Age varchar(30)Not Null,
Gender varchar(30)Not Null,
Sallary varchar(30)Not Null
);

create table NurseRecord (
FirstName varchar(30)Not Null,
LastName varchar(30)Not Null,
NurseID varchar(30)Not Null,
Address  varchar(30)Not Null,
City varchar(30)Not Null,
CNIC varchar(30)Not Null,
PhoneNo varchar(30)Not Null,
Email varchar(30)Not Null,
Age varchar(30)Not Null,
Gender varchar(10)Not Null,
Sallary varchar(30)Not Null
);

create table PatientRegistration 
(Name varchar(30)Not Null,
Address  varchar(30),
City varchar(30)Not Null,
CNIC varchar(30) primary key,
PhoneNo varchar(30)Not Null,
Age varchar(30)Not Null,
Gender varchar(10)Not Null
);

create table Rep_patient
(RepNo integer Identity(1,1)Not Null Primary Key, 
AssignToDoctor integer Not Null foreign key (AssignToDoctor) references DoctorRecord(ID)  ON UPDATE CASCADE ON DELETE CASCADE,
date   varchar(30)Not Null,
time varchar(30),
CNIC varchar(30) Not Null foreign key (CNIC) references PatientRegistration(CNIC) ON UPDATE CASCADE ON DELETE CASCADE
);

Create table PatientChecked(
 Pno integer Identity(1,1) Not Null,
 Name  varchar(30) Not Null,
 CNIC  varchar(30)Not Null,
 Age   varchar(30)Not Null,
 Gender varchar(30)Not Null,
 MedicineRecomended varchar(100) Not Null,
 Description varchar(150),
 Tests  varchar(100),
 RepNo  Integer Not Null Foreign Key (RepNo) References Rep_patient(RepNo),
 constraint PatientChecked_Pk primary key (Pno,CNIC),
 );
 
 Create table PatientRecord(
 Name varchar(30) Not Null,
 Address varchar(30),
 City varchar(30) ,
 CNIC varchar(30) Not Null foreign key (CNIC) references PatientRegistration(CNIC)  ,
 PhoneNo varchar(30) Not Null,
 Age varchar(30) Not Null,
 Gender varchar(30) Not Null,
 RepNo  Integer Not Null Foreign Key (RepNo) References Rep_patient(RepNo),
 AssignToDoctor integer Not Null foreign key (AssignToDoctor) references DoctorRecord(ID)  ON UPDATE CASCADE ON DELETE CASCADE,
 DoctorFirstName varchar(30) Not Null,
 DoctorLastName varchar(30) ,
 date   varchar(30) Not Null,
 time varchar(30) Not Null,
 MedicineRecomended varchar(100) Not Null,
 Description varchar(150),
 Tests  varchar(100),
 );
 GO
 ---------------------------------------------------------------------------------------------------------------
 create proc DropTables
AS
 drop table LoginAsDoctor
 drop table LoginAsAdmin
 drop table LoginAsRep
 drop table PatientRecord
 drop table PatientChecked
 drop table NurseRecord
 drop table Rep_patient
 drop table PatientRegistration
 drop table DoctorRecord
GO
----------------------------------------------------------------------------------------------------------------
 create proc SeeAllTablesData 
 AS
select * from LoginAsDoctor
select * from LoginAsAdmin
select * from LoginAsRep
select * from Rep_patient
select * from DoctorRecord
select * from PatientRegistration;
select * from PatientRecord
select * from NurseRecord
select * from PatientChecked
 GO
 ---------------------------------------------------------------------------------------------------------------
 exec SeeAllTablesData;
 exec DropTables;
 exec createTables;

 drop proc createTables;