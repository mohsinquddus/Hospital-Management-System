package hospitalmanagementsystem;
import java.sql.*;
import javax.swing.JOptionPane;
public class DatabaseConnectivity 
{
    Connection connection;
    public Connection getDatabaseConnectivity()
    {
        try
            { 
            DriverManager.registerDriver(new sun.jdbc.odbc.JdbcOdbcDriver());             
            connection = DriverManager.getConnection("jdbc:odbc:HMS");              
        }
        catch(Exception e)
        {             
            System.out.println(""+e);            
        }
        return connection;
    }
}
