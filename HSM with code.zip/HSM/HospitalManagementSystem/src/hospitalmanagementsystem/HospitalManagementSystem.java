package hospitalmanagementsystem;
import java.util.concurrent.TimeUnit;
import javax.swing.Timer;

public class HospitalManagementSystem extends javax.swing.JFrame{
     public int logined;
    public static void main(String[] args) throws InterruptedException {
        int a;
        Welcome wlcm=new Welcome();
        wlcm.setVisible(true);
        TimeUnit.SECONDS.sleep(3);
        wlcm.dispose();
        LoginAs la=new LoginAs();
        la.setVisible(true);        
    }   
}
